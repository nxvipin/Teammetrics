"""
Default Settings File
Please fill in the appropriate values and rename the file to settings.py
"""

PORT = '5441'
DEFAULTPORT = '5432'
DB = 'teammetrics'
USER = 'swvist'
HOST = 'localhost'
HOSTIP = '127.0.0.1'
PASS = 'swvist'
