"""
Default Settings File
Please fill in the appropriate values and rename the file to settings.py
"""

PORT = ''
DEFAULTPORT = ''
DB = ''
USER = ''
PASS = ''
HOST = ''
HOSTIP = ''
