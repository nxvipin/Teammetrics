#API Settings

#Current API Version
API_CURRENT_VERSION = 1

#Supported API versions
API_SUPPORTED_VERSIONS = [1]
